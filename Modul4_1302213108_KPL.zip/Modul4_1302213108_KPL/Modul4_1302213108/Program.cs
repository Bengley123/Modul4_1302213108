﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

namespace Modul_1302213108
{
    internal class program
    {
        public enum buah
        {
            Apel,
            Aprikot,
            Alpukat,
            Pisang,
            Paprika,
            Blackberry,
            Ceri,
            Kelapa,
            Jagung,
        };

        public class getKodeBuah
        {
            public static string getkode(buah buah)
            {
                string[] kodebuah = { "A00", "B00", "C00" , "D00" , "E00" , "F00" , "H00" , "I00" , "J00" , "K00" , "L00" , "M00" , "N00" };
                return kodebuah[(int)buah];
            }   
        }

        public static void Main(string[] args)
        {
            buah buah = buah.Apel;
            string kode = getKodeBuah.getkode(buah);
            Console.WriteLine("buah :" + buah + "\nkode buah ini: " + kode);
        }
    }
}
    

public enum karakter
{
    tengkurap,
    jongkok,
    berdiri,
    terbang,
}

public enum trigger
{
    tombolS,
    tombolW,
    tombolX,
}

public class posisikaraktergame
{
        
}

public class transisikaraktergame
{
    
}


transisi[]transisi2

